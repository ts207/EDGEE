### Events Without Detectors (Missing Coverage)

### Detectors Mapped to Unknown Events (Orphans)
- ABSORPTION_EVENT -> AbsorptionDetector
- ABSORPTION_PROXY -> AbsorptionProxyDetector
- BAND_BREAK -> BandBreakDetector
- BASIS_DISLOC -> BasisDislocationDetector
- BETA_SPIKE_EVENT -> BetaSpikeDetector
- BREAKOUT_TRIGGER -> BreakoutTriggerDetector
- CHOP_TO_TREND_SHIFT -> ChopToTrendDetector
- CLIMAX_VOLUME_BAR -> ClimaxVolumeDetector
- COPULA_PAIRS_TRADING -> CopulaPairsTradingDetector
- CORRELATION_BREAKDOWN_EVENT -> CorrelationBreakdownDetector
- CROSS_VENUE_DESYNC -> CrossVenueDesyncDetector
- DELEVERAGING_WAVE -> DeleveragingWaveDetector
- DEPTH_COLLAPSE -> DepthCollapseDetector
- DEPTH_STRESS_PROXY -> DepthStressProxyDetector
- FAILED_CONTINUATION -> FailedContinuationDetector
- FALSE_BREAKOUT -> FalseBreakoutDetector
- FEE_REGIME_CHANGE_EVENT -> FeeRegimeChangeDetector
- FLOW_EXHAUSTION_PROXY -> FlowExhaustionDetector
- FND_DISLOC -> FndDislocDetector
- FORCED_FLOW_EXHAUSTION -> FlowExhaustionDetector
- FUNDING_EXTREME_ONSET -> FundingExtremeOnsetDetector
- FUNDING_PERSISTENCE_TRIGGER -> FundingPersistenceDetector
- FUNDING_TIMESTAMP_EVENT -> FundingTimestampDetector
- GAP_OVERSHOOT -> GapOvershootDetector
- INDEX_COMPONENT_DIVERGENCE -> IndexComponentDivergenceDetector
- LEAD_LAG_BREAK -> LeadLagBreakDetector
- LIQUIDATION_CASCADE -> LiquidationCascadeDetector
- LIQUIDITY_GAP_PRINT -> LiquidityGapDetector
- LIQUIDITY_SHOCK -> LiquidityStressDetector
- LIQUIDITY_STRESS_DIRECT -> DirectLiquidityStressDetector
- LIQUIDITY_STRESS_PROXY -> ProxyLiquidityStressDetector
- LIQUIDITY_VACUUM -> LiquidityVacuumDetector
- MOMENTUM_DIVERGENCE_TRIGGER -> MomentumDivergenceDetector
- OI_FLUSH -> OIFlushDetector
- OI_SPIKE_NEGATIVE -> OISpikeNegativeDetector
- OI_SPIKE_POSITIVE -> OISpikePositiveDetector
- ORDERFLOW_IMBALANCE_SHOCK -> OrderflowImbalanceDetector
- OVERSHOOT_AFTER_SHOCK -> OvershootDetector
- POST_DELEVERAGING_REBOUND -> PostDeleveragingReboundDetector
- PRICE_VOL_IMBALANCE_PROXY -> PriceVolImbalanceProxyDetector
- PULLBACK_PIVOT -> PullbackPivotDetector
- RANGE_BREAKOUT -> RangeBreakoutDetector
- RANGE_COMPRESSION_END -> RangeCompressionDetector
- SCHEDULED_NEWS_WINDOW_EVENT -> ScheduledNewsDetector
- SESSION_CLOSE_EVENT -> SessionCloseDetector
- SESSION_OPEN_EVENT -> SessionOpenDetector
- SLIPPAGE_SPIKE_EVENT -> SlippageSpikeDetector
- SPOT_PERP_BASIS_SHOCK -> SpotPerpBasisShockDetector
- SPREAD_BLOWOUT -> SpreadBlowoutDetector
- SPREAD_REGIME_WIDENING_EVENT -> SpreadRegimeWideningDetector
- SUPPORT_RESISTANCE_BREAK -> SREventDetector
- SWEEP_STOPRUN -> StopRunDetector
- TREND_ACCELERATION -> TrendAccelerationDetector
- TREND_DECELERATION -> TrendDecelerationDetector
- TREND_EXHAUSTION_TRIGGER -> TrendExhaustionDetector
- TREND_TO_CHOP_SHIFT -> TrendToChopDetector
- VOL_CLUSTER_SHIFT -> VolClusterShiftDetector
- VOL_REGIME_SHIFT -> VolRegimeShiftDetector
- VOL_REGIME_SHIFT_EVENT -> VolRegimeShiftDetector
- VOL_RELAXATION_START -> VolRelaxationDetector
- VOL_SHOCK -> VolShockRelaxationDetector
- VOL_SPIKE -> VolSpikeDetector
- WICK_REVERSAL_PROXY -> WickReversalProxyDetector
- ZSCORE_STRETCH -> ZScoreStretchDetector

### Full Detector Mapping
| Event | Detector Class |
|-------|----------------|
| FUNDING_FLIP | FundingFlipDetector |
| FUNDING_NORMALIZATION_TRIGGER | FundingNormalizationDetector |
