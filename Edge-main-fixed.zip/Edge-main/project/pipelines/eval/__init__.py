"""Evaluation pipeline entrypoints."""

