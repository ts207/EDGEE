"""Runtime invariant pipeline stages."""
