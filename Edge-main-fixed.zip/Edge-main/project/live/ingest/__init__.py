"""Live data ingestion module."""
